---
title: Nest an Anchor Element Within a Paragraph
---
Nesting is simple, just add one element inside another:

    <p> click here for <a href="http://www.catphotoapp.com">cat photos</a></p>