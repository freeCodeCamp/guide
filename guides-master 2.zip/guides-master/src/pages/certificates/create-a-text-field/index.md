---
title: Create a Text Field
---
Text inputs are a convenient way to get input from your user.

You can create one like this:

    <input type="text">

Note that input elements are self-closing.