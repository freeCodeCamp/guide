---
title: Firebase
---
## Firebase
![Firebase Logo](https://firebase.google.com/_static/558bc0d91d/images/firebase/lockup.png)

### Overview
Firebase, in it's most basic form, was acquired by Google in October 2014. Since then, Google have acquired additional companies that complimented the original Firebase product. This selection of software tools now make up the current selection of Firebase  tools on offer today. 

#### More Information:

<a href="https://firebase.google.com/">Firebase</a>

<a href="https://en.wikipedia.org/wiki/Firebase">Wikipedia</a>

Here you can find examples of use Firebase in your projects
https://firebase.google.com/docs/samples/
