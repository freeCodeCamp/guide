---
title: Use Rgb to Color Elements Blue
---
The RGB value blue: `rgb(0, 0, 255)`