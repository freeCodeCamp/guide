---
title: Fill in the Blank with Placeholder Text
---
Web developers traditionally use **lorem ipsum** text as placeholder text. It's called lorem ipsum text because those are the first two words of a famous passage by Cicero of Ancient Rome.

**lorem ipsum** text has been used as placeholder text by typesetters since the 16th century, and this tradition continues on the web.

    <h1>Hello World</h1>

    <h2>CatPhotoApp</h2>

    <p>Kitty ipsum dolor sit amet, shed everywhere shed everywhere stretching attack your ankles chase the red dot, hairball run catnip eat the grass sniff.</p>