---
title: Change the Color of a Text
---
CSS allows us to change many styles. To change the color of an element we use `color`.

Here's how you would set your h2 element's text color to blue:

    <h2 style="color: blue">CatPhotoApp</h2>