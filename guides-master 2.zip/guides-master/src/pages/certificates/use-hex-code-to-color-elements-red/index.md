---
title: Use Hex Code to Color Elements Red
---
Hex code follows the red-green-blue, or rgb format. The first two digits of hex code represent the amount of red in the color. The third and fourth digit represent the amount of green. The fifth and sixth represent the amount of blue.

So to get the absolute brightest red, you would just use `F` for the first and second digits (the highest possible value) and `0` for the third, fourth, fifth and sixth digits (the lowest possible value).