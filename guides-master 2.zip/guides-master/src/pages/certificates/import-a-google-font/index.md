---
title: Import a Google Font
---
To import a font from Google or any other site, this is the format that you should follow:

    <link href="http://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css">

Once imported, it can then be used in the font-family property