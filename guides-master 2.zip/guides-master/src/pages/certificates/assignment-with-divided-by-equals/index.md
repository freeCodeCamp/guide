---
title: Assignment with Divided by Equals
---
The `/= operator` divides a variable by another number.

    myVar = myVar / 5;

Will divide `myVar` by `5`. This can be rewritten as:

    myVar /= 5;