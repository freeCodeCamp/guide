---
title: Nest One Array Within Another Array
---
You can nest arrays within other arrays, like this:`[["Bulls", 43]]`.