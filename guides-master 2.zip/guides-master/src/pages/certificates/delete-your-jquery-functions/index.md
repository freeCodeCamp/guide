---
title: Delete Your jQuery Functions
---
To delete the functions it is just as any other piece of code that you want to remove, select it and delete with the keyboard.