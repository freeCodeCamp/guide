---
title: Make Circular Images with a Border Radius
---
You can also use percentage to `border-radius` to make things round.

    .thick-green-border {
      border-color: green;
      border-width: 10px;
      border-style: solid;
      border-radius: 50%;
    }