---
title: Use Spans for Inline Elements
---
You can use use spans to create inline elements. By using the span element, you can put several elements together, and even style different parts of the same element differently.

    <p><span class = "text-danger">Things cats love:</span></p>