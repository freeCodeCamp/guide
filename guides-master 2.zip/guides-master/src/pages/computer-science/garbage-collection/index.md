---
title: Garbage Collection
---
## Garbage Collection

Garbage collection is the process in which programs try to free up memory space that is no longer used by variables, objects, and such.  Garbage collection is implemented differently for every language.  Most high-level programming languages have some sort of garbage collection built it.  Low-level programming languages may add garbage collection through libraries.

<!-- The article goes here, in GitHub-flavored Markdown. Feel free to add YouTube videos, images, and CodePen/JSBin embeds  -->

#### More Information:
<!-- Please add any articles you think might be helpful to read before writing the article -->
Please visit the <a href="https://en.wikipedia.org/wiki/Garbage_collection_(computer_science)">Garbage Collection (computer science)</a> Wikipedia page for more information.
