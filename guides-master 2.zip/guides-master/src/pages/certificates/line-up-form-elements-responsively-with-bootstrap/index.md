---
title: Line Up Form Elements Responsively with Bootstrap
---
We line up the form elements the same way we do with others, using divs.

    <div class="row">
    <div class="col-xs-7"><input type="text" class="form-control" placeholder="cat photo URL" required></div>
    <div class=col-xs-5><button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Submit</button></div>
    </div>