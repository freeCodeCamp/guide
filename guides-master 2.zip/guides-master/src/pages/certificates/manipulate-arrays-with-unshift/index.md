---
title: Manipulate Arrays with Unshift
---
`myArray.unshift('Paul');` Basically you call `unshift` and pass what was deleted.