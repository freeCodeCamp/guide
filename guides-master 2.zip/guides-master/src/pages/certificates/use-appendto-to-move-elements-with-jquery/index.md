---
title: Use Appendto to Move Elements with jQuery
---
jQuery has a function called `appendTo()` that allows you to select HTML elements and append them to another element.

For example, if we wanted to move target4 from our right well to our left well, we would use `$("#target4").appendTo("#left-well");`