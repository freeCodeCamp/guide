---
title: Make Dead Links Using the Hash Symbol
---
Replace your a element's `href` attribute with a `#`, also known as a hash symbol, to turn it into a dead link. Sometimes you want to add a elements to your website before you know where they will link.

This is also handy when you're changing the behavior of a link using jQuery, which we'll learn about later.