---
title: Add Your JavaScript Slot Machine Slots
---
For this part we should notify if they same number is returned three times or return `null` otherwise.

    if(slotOne !== slotTwo || slotTwo !== slotThree){
          return (null);
        }

If slot one and two are different, or slot two and three are not the same, then return `null`.