---
title: Use Hex Code for Specific Shades of Gray
---
We can also create other shades of gray by evenly mixing all three colors. We can go very close to true black. `background-color: #111111;`