---
title: Label Bootstrap Wells
---
You can add labels to the wells by using the headers `<h4>` above the well divs.