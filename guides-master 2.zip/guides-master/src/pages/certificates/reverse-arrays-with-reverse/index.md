---
title: Reverse Arrays with Reverse
---
You can use the .reverse() function to reverse the contents of an array.

    var array = [1,2,3,4,5,6,7];

    array = array.reverse();