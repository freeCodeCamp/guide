---
title: Use Rgb to Mix Color
---
RGB value orange: `rgb(255, 165, 0)`