---
title: Label Bootstrap Buttons
---
Just like we labeled our <a>wells</a>, we want to label our buttons.