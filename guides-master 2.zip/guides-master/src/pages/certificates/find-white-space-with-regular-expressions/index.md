---
title: Find White Space with Regular Expressions
---
We can also use selectors like`\s` to find spaces in a string.

It is used like this:

`/\s+/g`