---
title: Make Images Mobile Responsive
---
When using Bootstrap, if you want an image to be responsive, all you have to do is add the class `img-responsive` to it.

    <img class="img-responsive" src="http://bit.ly/fcc-running-cats">