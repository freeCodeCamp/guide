---
title: Use Hex Code to Color Elements Blue
---
Just as with <a>red</a> and the others.

    <style>
      body {
        background-color: #0000FF;
      }
    </style>