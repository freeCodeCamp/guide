---
title: Use Rgb to Color Elements White
---
background-color: rgb(255,255,255)