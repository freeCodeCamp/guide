---
title: Turn an Image into a Link
---
Creating images that link to things is essential and one of the most used things in Web Dev. Nest your image within an `a` element. Here's an example:

    <a href="#"><img src="http://bit.ly/fcc-running-cats"/></a>