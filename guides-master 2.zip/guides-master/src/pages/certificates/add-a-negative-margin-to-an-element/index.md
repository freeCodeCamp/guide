---
title: Add a Negative Margin to an Element
---
An element's `margin` controls the amount of space between an element's border and surrounding elements. If you set an element's margin to a **negative value**, the element will grow **larger**.