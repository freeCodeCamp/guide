---
title: Use Rgb to Color Elements Red
---
background-color: rgb(255, 0, 0)