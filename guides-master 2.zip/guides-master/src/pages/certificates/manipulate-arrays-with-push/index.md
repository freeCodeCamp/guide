---
title: Manipulate Arrays with Push
---
Not only can you `pop()` data off of the end of an array, you can also `push()` data onto the end of an array.

    myArray.push(["dog", 3]);