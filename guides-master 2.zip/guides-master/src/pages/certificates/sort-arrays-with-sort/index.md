---
title: Sort Arrays with Sort
---
You can use the method sort to easily sort the values in the array alphabetically or numerically

    var array = [1,3,2];

    array = array.sort();

This will return `[1, 2, 3]`