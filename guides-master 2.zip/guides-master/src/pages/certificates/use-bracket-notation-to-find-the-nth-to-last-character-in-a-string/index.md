---
title: Use Bracket Notation to Find the Nth to Last Character in a String
---
You can get the value of the third-to-last letter of the `var firstName = "Charles"` string by using `firstName[firstName.length - 3]`.