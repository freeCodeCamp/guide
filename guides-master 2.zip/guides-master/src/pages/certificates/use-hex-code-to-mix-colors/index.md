---
title: Use Hex Code to Mix Colors
---
Orange is pure red, mixed with some green, and no blue.

    <style>
      body {
        background-color: #FFA500;
      }
    </style>