---
title: Concatenate Strings with Concat
---
`.concat()` can be used to merge the contents of two arrays into one.

    array = array.concat(otherArray);