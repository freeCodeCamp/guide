---
title: Taste the Bootstrap Button Color Rainbow
---
The `btn-primary` class is the main color you'll use in your app. It is useful for highlighting actions you want your user to take. Note that this button will still need the `btn` and `btn-block` classes.

    <button class="btn btn-block btn-primary">Like</button>