---
title: Give Each Element a Unique Id
---
We will also want to be able to use jQuery to target each button by its unique id. So we add an unique id to each button.