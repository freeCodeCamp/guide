---
title: Target Even Numbered Elements Using jQuery
---
You can also target all the even-numbered elements.

Here's how you would target all the `odd-numbered` elements with class target and give them classes:

    $('.target:odd').addClass('animated shake');

This will shake all the even ones:

    $('.target:even').addClass("shake");