---
title: Link to External Pages with Anchor Elements
---
`a` elements, also known as anchor elements, are used to link to content outside of the current page.

Here's an example:

    <p>Here's a <a href="http://freecodecamp.com"> link to Free Code Camp</a> for you to follow.</p>