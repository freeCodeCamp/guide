---
title: Certificates
---
## Certificates

freeCodeCamp offers verified web development certificates for free to anyone who can complete each certificate's required projects.

In this folder, you'll find guides to hundreds of freeCodeCamp coding challenges and projects.

