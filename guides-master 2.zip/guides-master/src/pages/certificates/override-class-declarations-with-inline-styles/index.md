---
title: Override Class Declarations with Inline Styles
---
Remember, in line styles look like this: `<h1 style="color: green">` They will override everything else that was changing the text color of h1.