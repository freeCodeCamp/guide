---
title: Responsively Style Check Boxes
---
You can use Bootstrap's `col-xs-*` classes on form elements, too! This way, our checkboxes will be evenly spread out across the page, regardless of how wide the screen resolution is.

Nest all your checkboxes in a `<div class="row">` element. Then nest each of them in a `<div class="col-xs-4">` element.