---
title: Override Styles in Subsequent CSS
---
Your classes will override the body's CSS, if we add a new class that changes the same property, the last one will be the one applied.