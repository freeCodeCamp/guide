---
title: Create a Bootstrap Headline
---
To create a headline in boostrap you will need to add the class `.text-primary`.

    <h3 class="text-primary text-center"> jQuery Playground </h3>