---
title: Use Hex Code to Color Elements Green
---
Just as with <a>red</a> and the others.

    <style>
      body {
        background-color: #00FF00;
      }
    </style>