---
title: Create a Custom Heading
---
Using `div` and the custom grid layout we can create our own heading.

    <div class="row">
       <div class="col-xs-8">
         <h2 class="text-primary text-center">CatPhotoApp</h2>
       </div>
       <div class="col-xs-4">
         <a href="#"><img class="img-responsive thick-green-border" src="https://bit.ly/fcc-relaxing-cat"></a>
       </div>