---
title: Delivery Team
---
## Delivery Team

A scrum team is made up of the Product Owner (PO), the Scrum Master (SM), and the Delivery Team.

The delivery team is everyone but the PO and SM; the developers, testers, system analysts, database analysts, UI / UX analysts, and so on.

<!-- The article goes here, in GitHub-flavored Markdown. Feel free to add YouTube videos, images, and CodePen/JSBin embeds  -->

#### More Information:
<!-- Please add any articles you think might be helpful to read before writing the article -->


