---
title: Collocation Vs Distributed
---
## Collocation Vs Distributed
- Co-located refers to a team that sits together; same office. Ideally, everyone sitting together in adjacent offices or an open workspace.
- Distributed team members are scattered geographically; different buildings, cities, or even countries.
#### More Information:
<!-- Please add any articles you think might be helpful to read before writing the article -->


