---
title: Use Hex Code for Specific Colors
---
With CSS, we use 6 hexadecimal number to represent colors. For example, `#000000` is the lowest possible value, and it represents the color black.

This is the same as `#RRGGBB` which can also be simplified to `#RGB`.