---
title: Give a Background Color to a Div Element
---
You can set an element's background color with the `background-color` attribute.

For example, if you wanted an element's background color to be green, you'd use `.green-background { background-color: green; }` within your `style` element.