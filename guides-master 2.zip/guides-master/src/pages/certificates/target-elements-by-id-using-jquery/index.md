---
title: Target Elements by Id Using jQuery
---
You can also target elements by their id attributes. Note that, just like with CSS declarations, you type a # before the id's name.

    $("#target3").addClass("animated fadeOut");