---
title: Ditch Custom CSS for Bootstrap
---
We can clean up our code and make our Cat Photo App look more conventional by using Bootstrap's built-in styles instead of the custom styles we created earlier.

All you need to know is the built in <a href='http://getbootstrap.com/css/' target='_blank' rel='nofollow'>classes</a>.