---
title: Target Elements by Class Using jQuery
---
Just as we did before, we can also target elements by classes.

    $(".well").addClass("animated shake");