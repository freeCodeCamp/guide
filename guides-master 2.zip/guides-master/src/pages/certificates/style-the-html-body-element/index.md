---
title: Style the HTML Body Element
---
Every HTML page has the `body` element. and it is like the main page.