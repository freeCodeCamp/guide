---
title: Remove an Element Using jQuery
---
jQuery has a function called `.remove()` that will remove an HTML element entirely.

    $("#target4").remove();