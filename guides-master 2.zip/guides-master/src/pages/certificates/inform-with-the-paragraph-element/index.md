---
title: Inform with the Paragraph Element
---
`p` elements are the preferred element for normal-sized paragraph text on websites. P is short for "paragraph".

You can create a p element like so: `<p>I'm a p tag!</p>`.

    <h1>Hello World</h1>
    <h2>CatPhotoApp</h2>
    <p>Hello Paragraph</p>