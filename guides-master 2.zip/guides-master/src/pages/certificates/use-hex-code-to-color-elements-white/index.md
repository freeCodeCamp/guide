---
title: Use Hex Code to Color Elements White
---
`0` is the lowest number in hex code, and represents a complete absence of color. `F` is the highest number in hex code, and it represents the maximum possible brightness.