---
title: Declare String Variables
---
A String variable. It is nothing more than a "string" of characters. JavaScript strings are always wrapped in quotes.

    var myFirstName = 'Rafael';