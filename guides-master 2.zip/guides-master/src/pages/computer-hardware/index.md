---
title: Computer Hardware
---
## Computer Hardware

In this section, we explore the various hardware components of modern computers. 

## Parts of a Personal Computer

-Central Processing Unit (CPU)
-Expansion Cards (eg. GPU)
-Storage (SSD or HDD)
-Memory (RAM)
-Case
-Power Supply
-Motherboard
-Input and Output devices (eg. Keyboard and Mouse)
-Monitor
