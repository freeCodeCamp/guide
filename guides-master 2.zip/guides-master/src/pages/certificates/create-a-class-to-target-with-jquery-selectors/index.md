---
title: Create a Class to Target with jQuery Selectors
---
Not every class needs to have corresponding CSS. Sometimes we create classes just for the purpose of selecting these elements more easily using jQuery.

For this we use the `target` class on the `button` elements.