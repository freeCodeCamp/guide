---
title: Manipulate Arrays with Pop
---
Another way to change the data in an array is with the `.pop()` function.

`.pop()` is used to "pop" a value off of the end of an array. We can retrieve this value by performing `pop()` in a variable declaration.

Any type of variable can be "popped" off of an array.