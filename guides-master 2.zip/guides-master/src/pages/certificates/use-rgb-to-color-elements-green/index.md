---
title: Use Rgb to Color Elements Green
---
The rgb value green: `rgb(0, 255, 0)`