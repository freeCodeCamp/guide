---
title: Create a Bootstrap Button
---
Bootstrap has its own styles for button elements, which look much better than the plain HTML ones.

    <button type="submit" class="btn">Like</button>