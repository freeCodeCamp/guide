---
title: Remove Classes from an Element with jQuery
---
The same way we can add classes using jQuery, we an also remove them with `removeClass()`.

    $("button").removeClass("btn-default");