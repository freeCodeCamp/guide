---
title: House Our Page Within a Bootstrap Container Fluid Div
---
To make the content responsive, we use the `container-fluid` class.

    <div class="container-fluid">
    <h3 class="text-primary text-center">jQuery Playground</h3>
    </div>