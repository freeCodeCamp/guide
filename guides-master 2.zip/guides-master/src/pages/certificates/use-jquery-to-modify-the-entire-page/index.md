---
title: Use jQuery to Modify the Entire Page
---
jQuery can target the body element as well.

Here's how we would make the entire body fade out:

    $('body').addClass('animated fadeOut');