---
title: Use Rgb to Color Elements Gray
---
RGB value for gray: `rgb(128, 128, 128)`