---
title: Inherit Styles from the Body Element
---
The `body` element can be styled just like any other.

    <style>
      body {
        background-color: black;
        color: green;
        font-family: Monospace
      }

    </style>
    <h1>Hello World</h1>