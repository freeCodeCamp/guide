---
title: Modify Array Data with Indexes
---
We can also modify the data stored in arrays by using indexes.

For example:

    var ourArray = [3,2,1];
    ourArray[0] = 1; // equals [1,2,1]