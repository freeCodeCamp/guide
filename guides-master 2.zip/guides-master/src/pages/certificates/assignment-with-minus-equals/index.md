---
title: Assignment with Minus Equals
---
Like the `+= operator`, `-=` subtracts a number from a variable.

    myVar = myVar - 5;

will subtract `5` from `myVar`. This can be rewritten as:

    myVar -= 5;