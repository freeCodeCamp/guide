---
title: Split Strings with Split
---
You can use the `.split()` method to split a string into an array.

split uses the argument you give to to split the string.

    array = string.split(' ');