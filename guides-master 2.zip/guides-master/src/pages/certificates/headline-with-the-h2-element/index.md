---
title: Headline with the H2 Element
---
You can create different levels of Heading elements by using **h1, h2, h3, h4, h5, h6** which will result on different sizes.

    <h1>Hello World</h1>
    <h2>CatPhotoApp</h2>