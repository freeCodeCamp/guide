---
title: Use Hex Code to Color Elements Gray
---
We can also create different shades of gray by evenly mixing all three colors. `background-color: #808080;`