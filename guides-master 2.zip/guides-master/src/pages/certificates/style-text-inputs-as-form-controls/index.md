---
title: Style Text Inputs as Form Controls
---
You can add the `fa-paper-plane` Font Awesome icon by adding `<i class="fa fa-paper-plane"></i>` within your submit button element.

    <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane">Submit</i>