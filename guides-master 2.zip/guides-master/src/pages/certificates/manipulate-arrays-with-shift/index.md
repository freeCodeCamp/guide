---
title: Manipulate Arrays with Shift
---
`shift()` removes the first element unlike `pop()` which removes the last.