---
title: Containers
---
## Containers

Containers are an operating-system-level virtualization. It is an operating system feature in which the kernel allows the existence of multiple isolated user-space instances. Such instances, called containers may look like real computers from the point of view of programs running in them.
