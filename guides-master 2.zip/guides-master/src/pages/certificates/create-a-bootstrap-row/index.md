---
title: Create a Bootstrap Row
---
Create a div element with the class row.

    <div class="row"></div>